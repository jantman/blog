<?php
// script to show status information for network printers
require_once("/srv/www/htdocs/printer-snmp.php");
require_once("/srv/www/htdocs/printers.php");

if(isset($_GET['printerName']))
{
    $printerName = $_GET['printerName'];
    if(! isset($printerIPs[$printerName]))
    {
	echo "Invalid printer name!";
	die();
    }
}
else
{
    $printerName = "";
}

snmp_read_mib("/usr/share/snmp/mibs/Printer-MIB.mib");

?>

<html>
<head>
<?php echo "<title>Printer Status on ".$_SERVER["SERVER_NAME"]."</title>"; ?>
<link rel="stylesheet" href="printer.css" type="text/css">
</head>
<body>
<h2><center>
<?php echo "Printer Status on ".$_SERVER["SERVER_NAME"]; ?>
</center></h2>

<?php
if($printerName == "")
{
    foreach($printerIPs as $name => $printerIP)
    {
	showThePrinter($printerIP, $name);
	echo '<hr>';
    }
}
else
{
    showThePrinter($printerIPs[$printerName], $printerName);
}
?>

</body>
</html>

<?php
// preliminary handling of a printer
function showThePrinter($IP, $name)
{
    echo "<p>";
    $pingResult = pingPrinter($IP);
    if($pingResult > 50) // packet loss > 50%
    {
	// show an "offline" table for the printer
	echo '<table>';
	echo '<tr>';
	echo '<td width=50%><b><center>'.$name.'</center></b></td>';
	echo '<td width=50%><center><b><font color="red">OFFLINE ('.$IP.')</font></b></center></td>';
	echo '</tr>';
	echo '</table>';
    }
    else
    {
	// show the full printer table
	showPrinterTable($IP, $name);
    }
    echo "</p>";
}

function showPrinterTable($IP, $name)
{
    $sysInfo = getSysInfo($IP);
//    echo '<table border=1 width=95%>';
    echo '<table>';
    // header row
    echo '<tr>';
    echo '<td width=33%><center><b>'.$name.'</b></center></td>'; // name
    echo '<td width=33%><center><b><font color="green">ONLINE ('.$IP.')</b></center></td>'; // status
    echo '</tr>';
    // row 2 - display & alerts
    echo '<tr>';
    echo '<td>'; // cell for console display table
    // start display table
    echo '<center><table frame="box">';
    echo '<tr><td><u>Display</u></td>';
    echo '<td>';
    echo showPrinterDisplay($IP, $sysInfo["DeviceDescr"]);
    echo '</td>';
    echo '</tr>';
    echo '</table></center>';
    // end display table
    echo '</td>';
    echo '<td>'; // cell for alerts
    echo '<center><b>Alerts:</b>';
    $alerts = getAlerts($IP);
    foreach($alerts as $key => $val)
    {
	echo $val.'<br>';
    }
    echo '</center></td>';
    echo '</tr>';
    // row 3 - inputs & supplies
    echo '<tr>';
    echo '<td>'; // cell for inputs table
    echo '<center><b>Inputs:</b>';
    showInputsTable($IP);
    echo '</center></td>';
    echo '<td>'; // cell for supplies
    echo '<center><b>Supplies:</b>';
    showSuppliesTable($IP);
    echo '</center></td>';
    echo '</tr>';
    // row 4 - covers & sysInfo
    echo '<tr>';
    echo '<td>'; // cell for covers table
    echo '<center><b>Covers/Doors:</b>';
    showCoversTable($IP);
    echo '</center></td>';
    echo '<td>'; // cell for sysInfo
    echo '<center><b>System Info:</b>';
    showSysInfoTable($IP);
    echo '</center></td>';
    echo '</tr>';

    echo '</table>';
}

// generates a table that looks like the printer display
function showPrinterDisplay($IP, $DeviceDescr)
{
    echo '<center><code>'.getDisplay($IP).'</code><br></center>';
    echo '<table border=1 class="roster">';

    // show the display LEDs
    $LEDS = getLEDs($IP);
    foreach($LEDS as $name => $arr)
    {
	echo '<tr>';
	// show the color of the LED if it's lit
	// setup a cell with background color for LED
	showLEDcell($arr['color'], $arr['OnTime'], $arr['OffTime']);
	echo '<td>'.$name.'</td>';
	echo '</tr>';
    }

    echo '</table>';
}

function showLEDcell($color, $onTime, $offTime)
{
    if($onTime > 0 && $offTime != 0)
    {
	// flashing
	if(strtolower($color) == "green")
	{
	    echo '<td><img src="images/green-flash.gif"></td>';
	}
	elseif(strtolower($color) == "yellow")
	{
	    echo '<td><img src="images/yellow-flash.gif"></td>';
	}
	elseif(strtolower($color) == "red")
	{
	    echo '<td><img src="images/red-flash.gif"></td>';
	}
	else
	{
	    echo '<td bgcolor="'.$color.'">&nbsp;</td>';
	}
    }
    elseif($onTime > 0)
    {
	// continuous color
	if(strtolower($color) == "green")
	{
	    echo '<td><img src="images/green.gif"></td>';
	}
	elseif(strtolower($color) == "yellow")
	{
	    echo '<td><img src="images/yellow.gif"></td>';
	}
	elseif(strtolower($color) == "red")
	{
	    echo '<td><img src="images/red.gif"></td>';
	}
	else
	{
	    echo '<td bgcolor="'.$color.'">&nbsp;</td>';
	}
    }
    else
    {
	// nothing
	echo '<td><img src="images/white.gif"></td>';
    }
}

// generate a table for the inputs
function showInputsTable($IP)
{
    $inputs = getInputs($IP);

    echo '<table border=1 class="roster">';
    echo '<tr>';
    echo '<td><b>Name</b></td>';
    echo '<td><b>Type</b></td>';
    echo '<td><b>Status</b></td>';
    echo '<td><b>Media Name</b></td>';
    echo '<td><b>Media Type</b></td>';
    echo '<td><b>Description</b></td>';
    echo '<td><b>Level / Capacity</b></td>';
    echo '<tr>';
    foreach($inputs as $name => $arr)
    {
	echo '<tr>';
	echo '<td>'.$name.'</td>';
	echo '<td>'.$arr['type'].'</td>';
	echo '<td>'.$arr['status'].'</td>';
	echo '<td>'.$arr['mediaName'].'</td>';
	echo '<td>'.$arr['mediaType'].'</td>';
	echo '<td>'.$arr['description'].'</td>';
	if($arr['currentLevel'] == -2)	{ echo '<td>UNKNOWN</td>';}
	elseif($arr['currentLevel'] == -3) { echo '<td>>=1 / '.$arr['maxCapacity'].'</td>';}
	else { echo '<td>'.$arr['currentLevel'].' / '.$arr['maxCapacity'].'</td>';}
	echo '<tr>';
    }
    echo '</table>';
}

// generate a table for the supplies
function showSuppliesTable($IP)
{
    $supplies = getSupplies($IP);

    echo '<table border=1 class="roster">';
    echo '<tr>';
    echo '<td><b>Description</b></td>';
    echo '<td><b>Type</b></td>';
    echo '<td><b>Level / Capacity</b></td>';
    echo '<tr>';
    foreach($supplies as $key => $arr)
    {
	echo '<tr>';
	echo '<td>'.$arr['description'].'</td>';
	echo '<td>'.$arr['type'].'</td>';
	if($arr['level'] == -2)	{ echo '<td>UNKNOWN</td>';}
	elseif($arr['level'] == -3) { echo '<td>>=1 / '.$arr['maxCapacity'].'</td>';}
	elseif($arr['level'] == "PRESENT") { echo '<td>'.$arr['level'].'</td>';}
	elseif($arr['level'] == "UNKNOWN") { echo '<td>'.$arr['level'].'</td>';}
	else { echo '<td>'.$arr['level'].' / '.$arr['maxCapacity'].'</td>';}
	echo '<tr>';
    }
    echo '</table>';
}

// generate a table for the covers
function showCoversTable($IP)
{
    $covers = getCoverStatus($IP);

    echo '<table border=1 class="roster">';
    echo '<tr>';
    echo '<td><b>Name</b></td>';
    echo '<td><b>Status</b></td>';
    echo '<tr>';
    foreach($covers as $name => $status)
    {
	echo '<tr>';
	echo '<td>'.$name.'</td>';
	if($status != "coverClosed")
	{
	    echo '<td><font color="red"><b>'.$status.'</b></font></td>';
	}
	else
	{
	    echo '<td>'.$status.'</td>';
	}
	echo '<tr>';
    }
    echo '</table>';
}

// generate a table for the SysInfo
function showSysInfoTable($IP)
{
    $arr = getSysInfo($IP);

    echo '<table border=1 class="roster">';
    echo '<tr><td><b>Name</b></td><td>'.$arr['sysName'].'</td></tr>';
    echo '<tr><td><b>Description</b></td><td>'.$arr['sysDescr'].'</td></tr>';
    echo '<tr><td><b>Uptime</b></td><td>'.$arr['uptime'].'</td></tr>';
    echo '<tr><td><b>Device Desc.</b></td><td>'.$arr['DeviceDescr'].'</td></tr>';
    echo '<tr><td><b>MAC</b></td><td>'.$arr['MAC'].'</td></tr>';
    echo '</table>';
}

?>