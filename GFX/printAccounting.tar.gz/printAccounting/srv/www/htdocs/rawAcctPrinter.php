<html>
<head>
<title>View Raw Accounting Data by Printer</title>
</head>
<body>
<h2><center>Raw Accounting Data
<?php
if(isset($_GET['printerName']))
{
    $printerName = mysql_escape_string($_GET['printerName']);
    echo ' for queue '.$printerName;
}
else
{
    echo ' for all printers';
}
if(isset($_GET['days']))
{
    $days = mysql_escape_string($_GET['days']);
    echo ' in last '.$days.' days.';
}
else
{
    echo '.';
}
?>
</center></h2>

<?php
// Time-stamp: " "
// $ Id $

// View raw accounting data by printer

// MySQL Stuff
$dbName = 'printAcct';
$tblName = 'rawJobAccounting';
$conn = mysql_connect() or die ("Error connecting to MySQL: ".mysql_error());
mysql_select_db($dbName) or die ("Error selecting database: ".mysql_error());

$query = "SELECT queue,jobID,userName,userIP,timeStamp,pkpgcount,inkPercent,paperSize,copies FROM ".$tblName;
if(isset($printerName)){ $query .= ' WHERE queue="'.$printerName.'"';}
if(isset($printerName) && isset($days))
{
    $query .= " AND timeStamp > ".(time() - ($days * 86400));
}
elseif(isset($days))
{
    $query .= " WHERE timeStamp > ".(time() - ($days * 86400));
}
$query .= " ORDER BY queue ASC, jobID DESC;";
$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

// setup table in raw html
?>
<table border=1 width=100%>
<tr>
<td><b>Printer</b></td>
<td><b>Job ID</b></td>
<td><b>User</b></td>
<td><b>IP</b></td>
<td><b>Date/Time</b></td>
<td><b>Pages</b></td>
<td><b>Copies</b></td>
<td><b>Ink %<br>Coverage</b></td>
<td><b>Paper<br>Size</b></td>
</tr>

<?php
$currentQueue = "";
while ($row = mysql_fetch_array($result))
{
	echo '<tr>';
	if($currentQueue == $row['queue'])
	{
	    echo '<td>&nbsp;</td>';
	}
	else
	{
	    echo '<td>'.$row['queue'].'</td>';
	}
	$currentQueue = $row['queue'];
	echo '<td>'.$row['jobID'].'</td>';
	echo '<td>'.$row['userName'].'</td>';
	echo '<td>'.$row['userIP'].'</td>';
	echo '<td>'.date("Y-m-d",$row['timeStamp'])." ".date("H:i:s",$row['timeStamp']).'</td>';
	echo '<td>'.$row['pkpgcount'].'</td>';
	echo '<td>'.$row['copies'].'</td>';
	echo '<td>'.$row['inkPercent'].'</td>';
	echo '<td>'.$row['paperSize'].'</td>';
	echo '</tr>';
}

mysql_close($conn);
?>

</table>
