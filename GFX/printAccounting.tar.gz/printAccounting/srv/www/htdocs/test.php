<?php

require_once("printer-snmp.php");

$printerIP = "192.168.2.5";
echo "lifetime=";
echo getLifetimeCount($printerIP);
echo "\n";
echo "powerOn=";
echo getPowerOnCount($printerIP);
echo "\n";

?>