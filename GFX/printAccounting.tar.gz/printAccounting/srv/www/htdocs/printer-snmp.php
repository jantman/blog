<?php

// PHP script to get information about a printer via SNMP

$community = "public";

/*
 * FUNCTION DOCUMENTATION:
 *
 * getTree($printerIP, $OID) returns the return value from snmpwalk
 *
 * getValue($printerIP, $OID) returns one specific value
 *
 * getAlerts($printerIP) returns array of alerts like (key (int) => description (str))
 *
 * getDisplay($printerIP) returns string of current LCD display text
 *
 * getLEDs($printerIP) returns an array of arrays like:
 *    description (str) = array("color" (str), "OnTime" (int), "OffTime" (int))
 *
 * getLifetimeCount($printerIP) returns an integer lifetime page count
 *
 * getPowerOnCount($printerIP) returns an integer page count since last power-on
 *
 * getSysInfo($printerIP) returns an array like:
 *   ("sysDescr" (str), "uptime" (str), "sysName" (str), "MAC" (str), "DeviceDescr" (str))
 *
 * getCoverStatus($printerIP) returns an array like (coverName (str) => status (array))
 *   status array is like: 
 *   
 * getInputs($printerIP) returns an array of arrays with information on input trays, etc. like:
 *   inputName = array("type" (str), "maxCapacity" (int), "currentLevel" (int), "status" (int), "mediaName" (str), "description" (str), "mediaType" (str))
 *
 * getSupplies($printerIP) returns an array of arrays each like:
 *   key (int) = array("description" (str), "type" (str), "maxCapacity" (int), "level" (str))
 *
 */

// gets all values in an OID
function getTree($printerIP, $OID)
{
	global $community;
	return snmpwalk($printerIP, $community, $OID);
}

// gets a specific value
function getValue($printerIP, $OID)
{
	global $community;
	return snmpget($printerIP, $community, $OID);
}

// get printer alerts
function getAlerts($printerIP)
{
	// handle the SNMP stuff
	global $community;
	$description = snmpwalk($printerIP, $community, "Printer-MIB::prtAlertDescription.1");
	
	foreach($description as $key => $val)
	{
		// get rid of everything before and including the first quote (around this string)
		$val = substr($val, strpos($val, '"')+1);
		// get rid of the training quote if any
		$val = substr($val, 0, strrpos($val, '"'));
		// trim off any whitespace
		$val = trim($val);
		$description[$key] = $val;
	}	

	// return the array
	return $description;
}

// get console display information
function getDisplay($printerIP)
{
	// handle the SNMP stuff
	global $community;
	$display = snmpwalk($printerIP, $community, "Printer-MIB::prtConsoleDisplayBufferText.1");

	$text = "";	

	foreach($display as $key => $val)
	{
		// get rid of everything before and including the first quote (around this string)
		$val = substr($val, strpos($val, '"')+1);
		// get rid of the training quote if any
		$val = substr($val, 0, strrpos($val, '"'));
		// trim off any whitespace
		$val = trim($val);
		$text .= $val."\n";
	}	

	// trim whitespace and return string
	$text = trim($text);
	return $text;
}

function getLEDs($printerIP)
{
	// handle the SNMP stuff
	global $community;
	$description = snmpwalk($printerIP, $community, "Printer-MIB::prtConsoleDescription.1");
	$color = snmpwalk($printerIP, $community, "Printer-MIB::prtConsoleColor.1");
	$onTime = snmpwalk($printerIP, $community, "Printer-MIB::prtConsoleOnTime.1");
	$offTime = snmpwalk($printerIP, $community, "Printer-MIB::prtConsoleOffTime.1");

	$LEDs = array(); // array for finished product

	foreach($description as $key => $val)
	{
		// get rid of everything before and including the first quote (around this string)
		$val = substr($val, strpos($val, '"')+1);
		// get rid of the training quote if any
		$val = substr($val, 0, strrpos($val, '"'));
		// trim off any whitespace
		$val = trim($val);

		// get values for the other information
		$colorVal = $color[$key];
		$colorVal = substr($colorVal, strpos($colorVal, ' ')+1);
		$colorVal = substr($colorVal, 0, strrpos($colorVal, '('));
		$colorVal = trim($colorVal);

		$onTimeVal = $onTime[$key];
		$onTimeVal = substr($onTimeVal, strpos($onTimeVal, ' ')+1);
		$onTimeVal = (int)$onTimeVal;
		$offTimeVal = $offTime[$key];
		$offTimeVal = substr($offTimeVal, strpos($offTimeVal, ' ')+1);
		$offTimeVal = (int)$offTimeVal;

		// make an array
		$temp = array("color" => $colorVal, "OnTime" => $onTimeVal, "OffTime" => $offTimeVal);

		// add the array to our big return array
		$LEDs[$val] = $temp;
	}	

	// return the array
	return $LEDs;
}

// get the lifetime impressions count
function getLifetimeCount($printerIP)
{
	global $community;
	$count =  snmpget($printerIP, $community, "Printer-MIB::prtMarkerLifeCount.1.1");
	$count = substr($count, strpos($count, ' ')+1);
	$count = (int)$count;
	return $count;
}

// get the impressions count since last power on
function getPowerOnCount($printerIP)
{
	global $community;
	$count =  snmpget($printerIP, $community, "Printer-MIB::prtMarkerPowerOnCount.1.1");
	$count = substr($count, strpos($count, ' ')+1);
	$count = (int)$count;
	return $count;
}

// system information
function getSysInfo($printerIP)
{
	// handle the SNMP stuff
	global $community;

	$sysInfo = array();

	// get the stuff and format the results
	$sysDescr = snmpget($printerIP, $community, "SNMPv2-MIB::sysDescr.0");
	$sysDescr = substr($sysDescr, strpos($sysDescr, ' ')+1);
	$uptime = snmpget($printerIP, $community, "DISMAN-EVENT-MIB::sysUpTimeInstance");
	$uptime = substr($uptime, strpos($uptime, ' ')+1);
	$uptime = substr($uptime, strpos($uptime, ' ')+1); // we'll take from the second space, just the human-readable
	$sysName = snmpget($printerIP, $community, "SNMPv2-MIB::sysName.0");
	$sysName = substr($sysName, strpos($sysName, ' ')+1);
	$MAC = snmpget($printerIP, $community, "IF-MIB::ifPhysAddress.1");
	$MAC = substr($MAC, strpos($MAC, ' ')+1);
	$DeviceDescr = snmpget($printerIP, $community, "HOST-RESOURCES-MIB::hrDeviceDescr.1");
	$DeviceDescr = substr($DeviceDescr, strpos($DeviceDescr, ' ')+1);

	// put everything in the array
	$sysInfo['sysDescr'] = $sysDescr;
	$sysInfo['uptime'] = $uptime;
	$sysInfo['sysName'] = $sysName;
	$sysInfo['MAC'] = $MAC;
	$sysInfo['DeviceDescr'] = $DeviceDescr;

	// return the array
	return $sysInfo;
}

// cover status
function getCoverStatus($printerIP)
{
	// handle the SNMP stuff
	global $community;
	$covers = snmpwalk($printerIP, $community, "Printer-MIB::prtCoverDescription.1");
	$status = snmpwalk($printerIP, $community, "Printer-MIB::prtCoverStatus.1");

	$result = array(); // the final array

	foreach($covers as $key => $val)
	{
		// get rid of everything before and including the first quote (around this string)
		$val = substr($val, strpos($val, '"')+1);
		// get rid of the training quote if any
		$val = substr($val, 0, strrpos($val, '"'));
		// trim off any whitespace
		$val = trim($val);

		$cStatus = $status[$key];

		// get rid of everything before and including the first space
		$cStatus = substr($cStatus, strpos($cStatus, ' ')+1);
		// get rid of everything after '('
		$cStatus = substr($cStatus, 0, strrpos($cStatus, '('));
		// trim off any whitespace
		$cStatus = trim($cStatus);

		$result[$val] = $cStatus;
	}	

	// return the array
	return $result;
}

// media input information
function getInputs($printerIP)
{
	// handle the SNMP stuff
	global $community;
	$type = snmpwalk($printerIP, $community, "Printer-MIB::prtInputType.1");
	$maxCapacity = snmpwalk($printerIP, $community, "Printer-MIB::prtInputMaxCapacity.1");
	$currentLevel = snmpwalk($printerIP, $community, "Printer-MIB::prtInputCurrentLevel.1");
	$status = snmpwalk($printerIP, $community, "Printer-MIB::prtInputStatus.1");
	$mediaName = snmpwalk($printerIP, $community, "Printer-MIB::prtInputMediaName.1");
	$name = snmpwalk($printerIP, $community, "Printer-MIB::prtInputName.1");
	$description =  snmpwalk($printerIP, $community, "Printer-MIB::prtInputDescription.1");
	$mediaType = snmpwalk($printerIP, $community, "Printer-MIB::prtInputMediaType.1");

	$result = array(); // the final array

	foreach($name as $key => $val)
	{
	    $temp = array();
	    // cleanup the val string
	    $val = substr($val, strpos($val, '"')+1);
	    $val = substr($val, 0, strrpos($val, '"'));
	    $val = trim($val);

	    // temp variables for this element
	    $t_type = $type[$key];
	    $t_type = substr($t_type, strpos($t_type, ' ')+1);
	    $t_type = substr($t_type, 0, strrpos($t_type, '('));
	    $t_type = trim($t_type);
	    $temp["type"] = $t_type;

	    $t_maxCapacity = $maxCapacity[$key];
	    $t_maxCapacity = substr($t_maxCapacity, strpos($t_maxCapacity, ' ')+1);
	    $t_maxCapacity = trim($t_maxCapacity);
	    $temp["maxCapacity"] = (int)$t_maxCapacity;

	    $t_currentLevel = $currentLevel[$key];
	    $t_currentLevel = substr($t_currentLevel, strpos($t_currentLevel, ' ')+1);
	    $t_currentLevel = trim($t_currentLevel);
	    $temp["currentLevel"] = (int)$t_currentLevel;

	    $t_status = $status[$key];
	    $t_status = substr($t_status, strpos($t_status, ' ')+1);
	    $t_status = trim($t_status);
	    $temp["status"] = (int)$t_status;

	    $t_mediaName = $mediaName[$key];
	    $t_mediaName = substr($t_mediaName, strpos($t_mediaName, '"')+1);
	    $t_mediaName = substr($t_mediaName, 0, strrpos($t_mediaName, '"'));
	    $t_mediaName = trim($t_mediaName);
	    $temp["mediaName"] = $t_mediaName;

	    $t_description = $description[$key];
	    $t_description = substr($t_description, strpos($t_description, '"')+1);
	    $t_description = substr($t_description, 0, strrpos($t_description, '"'));
	    $t_description = trim($t_description);
	    $temp["description"] = $t_description;

	    $t_mediaType = $mediaType[$key];
	    $t_mediaType = substr($t_mediaType, strpos($t_mediaType, '"')+1);
	    $t_mediaType = substr($t_mediaType, 0, strrpos($t_mediaType, '"'));
	    $t_mediaType = trim($t_mediaType);
	    $temp["mediaType"] = $t_mediaType;

	    $result[$val] = $temp;
	}	

	// return the array
	return $result;
}

// supplies information
function getSupplies($printerIP)
{
	// handle the SNMP stuff
	global $community;
	$type = snmpwalk($printerIP, $community, "Printer-MIB::prtMarkerSuppliesType.1");
	$description =  snmpwalk($printerIP, $community, "Printer-MIB::prtMarkerSuppliesDescription.1");
	$maxCapacity = snmpwalk($printerIP, $community, "Printer-MIB::prtMarkerSuppliesMaxCapacity.1");
	$level = snmpwalk($printerIP, $community, "Printer-MIB::prtMarkerSuppliesLevel.1");

	$result = array(); // the final array

	foreach($description as $key => $val)
	{
	    $temp = array();

	    // cleanup the val string
	    $val = substr($val, strpos($val, '"')+1);
	    $val = substr($val, 0, strrpos($val, '"'));
	    $val = trim($val);
	    $temp["description"] = $val;

	    // temp variables for this element
	    $t_type = $type[$key];
	    $t_type = substr($t_type, strpos($t_type, ' ')+1);
	    $t_type = substr($t_type, 0, strrpos($t_type, '('));
	    $t_type = trim($t_type);
	    $temp["type"] = $t_type;

	    $t_maxCapacity = $maxCapacity[$key];
	    $t_maxCapacity = substr($t_maxCapacity, strpos($t_maxCapacity, ' ')+1);
	    $t_maxCapacity = trim($t_maxCapacity);
	    $temp["maxCapacity"] = (int)$t_maxCapacity;

	    $t_level = $level[$key];
	    $t_level = substr($t_level, strpos($t_level, ' ')+1);
	    $t_level = trim($t_level);
	    if($t_level == "-2"){ $t_level = "UNKNOWN";}
	    if($t_level == "-3"){ $t_level = "PRESENT";}
	    $temp["level"] = $t_level;

	    $result[$key] = $temp;
	}	

	// return the array
	return $result;
}

// returns percentage of packet loss in 6 pings
function pingPrinter($IP)
{
    $result = shell_exec("ping -c 1 -q ".$IP." | grep loss");
    $result = substr($result, 0, strpos($result, "%"));
    $result = substr($result, strrpos($result, " "));
    $result = trim($result);
    return (int)$result;
}

?>
