<?php

// Time-stamp: "2007-11-30 00:05:05 jantman"
// $ Id $

// Web interface for print accounting
// http://www.jasonantman.com

require_once("printers.php");
require_once("printer-snmp.php");
require_once("printer-local-cups.php");
?>
<html>
<head>
</head>
<body>
<h2><center>
<?php echo "Printing Overview on ".$_SERVER["SERVER_NAME"]; ?>
</center></h2>
<p>

<?php
$printerCount = 1;
echo '<table width=100%>';
foreach($printerIPs as $name => $IP)
{
    if(($printerCount % 2) == 1)
    {
	// start a row
	echo '<tr><td width=50%>';
    }
    else
    {
	echo '<td width=50%>';
    }
    echo '<table frame="border" width=100%>';
    echo '<tr>';
    echo '<td><b>'.$name.'</b></td>';
    echo '<td>';
    if(pingPrinter($IP) < 50)
    {
	echo '<font color="green">Online ('.$IP.')</font>';
	$printerUp = true;
    }
    else
    {
	echo '<font color="red">Offline ('.$IP.')</font>';
	$printerUp = false;
    }
    echo '</td>';
    echo '</tr>';
    echo '<tr>';
    echo '<td><b><a href="rawAcctPrinter.php?printerName='.$name.'&days=30">Recent Jobs</a></b></td>';
    echo '<td><b><a href="acctPrinter.php?printerName="'.$name.'">Accounting</a></b></td>';
    echo '</tr>';
    echo '<tr>';
    echo '<td>';
    if($printerUp)
    {
	// show alerts
	echo '<center><b>Alerts:</b>';
	$temp = getAlerts($IP);
	foreach($temp as $text)
	{
	    echo '<br>'.$text;
	}
	echo '</center>';
    }
    else
    {
	echo '&nbsp;';
    }
    echo '</td>';
    echo '<td>';
    if($printerUp)
    {
	// show media/input status
	echo '<b>Media Status:</b>';
    }
    else
    {
	echo '&nbsp;';
    }
    echo '</td>';
    echo '</tr>';
    echo '</table>';
    if(($printerCount % 2) == 1)
    {
	echo '</td>';
    }
    else
    {
	// end a row
	echo '</td></tr>';
    }
    $printerCount++;
}
echo '</table>';
echo '</p>';
echo '<p>';
$jobs = getCUPSjobsBYqueue();
echo '<h3>Current Jobs:</h3>'."\n";
if(sizeof($jobs) > 0)
{
    echo '<table border=1>'."\n";
    // layout the table
    echo '<tr>';
    echo '<td><b>Queue</b></td>';
    echo '<td><b>Job ID</b></td>';
    echo '<td><b>User</b></td>';
    echo '<td><b>Size</b></td>';
    echo '<td><b>Date Started</b></td>';
    echo '</tr>'."\n";
    
    // deal with the jobs array
    foreach($jobs as $printer => $arr)
    {
	$jobcount = 0;
	foreach($arr as $id => $job)
	{
	    echo '<tr>';
	    if($jobcount == 0)
	    {
		// show the printer name for the first job
		echo '<td>'.$printer.'</td>';
	    }
	    else
	    {
		// multiple job, don't show printer name
		echo '<td>&nbsp;</td>';
	    }
	    echo '<td>'.$id.'</td>';
	    echo '<td>'.$job['user'].'</td>';
	    echo '<td>'.$job['size'].'</td>';
	    echo '<td>'.$job['dateStarted'].'</td>';
	    echo '</tr>'."\n";
	    $jobcount++;
	}
    }
    echo '</table>';
}
else
{
    echo "<b>No Jobs.</b>";
}
echo '</p>';
?>

</body>
</html>
