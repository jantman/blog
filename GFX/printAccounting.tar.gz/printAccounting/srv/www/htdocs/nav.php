<?php

// Time-stamp: "2007-11-30 00:23:48 jantman"
// $ Id $

// Web interface for print accounting
// http://www.jasonantman.com

require_once("printers.php");

?>
<html>
<head>
</head>
<body>

<table>
<tr>
<td>
<b><a href="main.php" target="mainFrame">Summary</a></b>
</td>
<td align="right">
<a href="https://printserv1-vm.localdomain:631/" target="mainFrame">CUPS</a>&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;
<a href="https://printserv1-vm.localdomain:631/printers/" target="mainFrame">Printers</a>&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;
<a href="https://printserv1-vm.localdomain:631/jobs/" target="mainFrame">Jobs</a>
</td>
</tr>
<tr>
<td>
<b>Printer Info:</b> 
</td>
<td>
<?php
// list printers here
$count = 0;
foreach($printerIPs as $name => $IP)
{
    if($count != 0)
    {
	echo '-&nbsp;&nbsp;&nbsp;';
    }
    echo '<a href="printerStatus.php?printerName='.$name.'" target="mainFrame">'.$name.'</a>';
    echo '&nbsp;&nbsp;&nbsp;';
    $count++;
}
?>
</td>
</tr>
<tr>
<td>
<b>Simple Accounting:</b>
</td>
<td>
<a href="acctUser.php" target="mainFrame">User</a>&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;
<a href="acctIP.php" target="mainFrame">IP Address/Host</a>&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;
<a href="acctPrinter.php" target="mainFrame">Printer</a>&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;
<a href="acctSize.php" target="mainFrame">Page Size</a>
</td>
</tr>
<tr>
<td>
<b>Raw Accounting:</b>
</td>
<td>
<a href="rawAcctUser.php?days=30" target="mainFrame">User</a>&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;
<a href="rawAcctIP.php?days=30" target="mainFrame">IP Address/Host</a>&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;
<a href="rawAcctPrinter.php?days=30" target="mainFrame">Printer</a>&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;
<a href="rawAcctSize.php?days=30" target="mainFrame">Page Size</a>
</td>
</tr>
</table>

</body>
</html>
