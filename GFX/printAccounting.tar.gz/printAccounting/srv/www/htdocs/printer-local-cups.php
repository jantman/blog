<?php

// PHP script to get information about a printer via local CUPS command-line tools

/*
 * FUNCTION DOCUMENTATION:
 *
 * getCUPSjobsBYid() returns all jobs for all queues as an array like:
 *   "printerName-id" = array(printerName, id, user, size, dateStarted)
 *
 * getCUPSjobsBYqueue() returns all jobs as a multidimensional array like:
 *    array[printerName][id] = array(user, size, dateStarted)
 */

// gets all jobs for all queues
function getCUPSjobsBYid()
{
    $input = shell_exec("lpstat -o");
    $lines = explode("\n", $input);

    $result = array();

    // loop through input lines
    foreach($lines as $line)
    {
	if(trim($line) != "")
	{
	    $lineArr = explode(" ", $line);
	    $printerString = array_shift($lineArr);
	    $printerName = substr($printerString, 0, strpos($printerString, "-"));
	    $id = substr($printerString, strpos($printerString, "-")+1, (strlen($printerString) - strpos($printerString, "-")));
	    // loop through array and find next non-empty value
	    $head = array_shift($lineArr);
	    while($head == "")
	    {
		$head = array_shift($lineArr);
	    }
	    $user = $head;
	    // loop through array and find next non-empty value
	    $head = array_shift($lineArr);
	    while($head == "")
	    {
		$head = array_shift($lineArr);
	    }
	    $size = $head;
	    // loop through array and find next non-empty value
	    $head = array_shift($lineArr);
	    while($head == "")
	    {
		$head = array_shift($lineArr);
	    }
	    $dateStarted = $head;
	    foreach($lineArr as $word)
	    {
		$dateStarted .= " ".$word;
	    }
	    $temp = array("printerName" => $printerName, "id" => $id, "user" => $user, "size" => $size, "dateStarted" => $dateStarted);
	    $result[$printerString] = $temp;
	}
    }
    return $result;
}

function getCUPSjobsBYqueue()
{
    $jobs = getCUPSjobsBYid();

    $result = array();

    foreach($jobs as $printerString => $array)
    {
	$printerName = substr($printerString, 0, strpos($printerString, "-"));
	$result[$printerName] = array();
    }

    foreach($jobs as $printerString => $arr)
    {
	$temp = array("user" => $arr['user'], "size" => $arr['size'], "dateStarted" => $arr['dateStarted']);
	$result[$arr['printerName']][$arr['id']] = $temp;
    }
    return $result;
}

?>
