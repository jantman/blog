<?php

$printerIPs = array();
$printerIPs["XeroxN4525"] = "192.168.5.11";
$printerIPs["Brother"] = "192.168.2.5";
$printerIPs["HPLJ4500"] = "192.168.5.12";

?>