#! /usr/bin/php

<?php

// test of PJL access

$address = "192.168.2.231";
$port = 9100;
// don't timeout!
set_time_limit(10);

/* Create a TCP/IP socket. */
$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
if ($socket === false) {
    echo "socket_create() failed: reason: "
    . socket_strerror(socket_last_error()) . "\n";
} else {
    echo "OK.\n";
}

echo "Attempting to connect to '$address' on port '$port'...";
$result = socket_connect($socket, $address, $port);
if ($result === false) {
    echo "socket_connect() failed.\nReason: ($result) "
    . socket_strerror(socket_last_error($socket)) . "\n";
} else {
    echo "OK.\n";
}



$query = "\033%-12345X\@PJL INFO PAGECOUNT\r\n";
socket_write($socket, $query, strlen ($query)) or die("Could not write output\n");

// read client input
$output = socket_read($socket, 1024) or die("Could not read input\n");

echo $output;

socket_close($socket);
exit(0);

$query = "@PJL INFO STATUS\r\n";
socket_write($socket, $query, strlen ($query)) or die("Could not write output\n");

// read client input
$output = socket_read($socket, 1024) or die("Could not read input\n");
echo $output;


// close sockets
socket_close($socket);
?>

?>
