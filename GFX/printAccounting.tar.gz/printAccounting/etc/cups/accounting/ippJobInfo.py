#! /usr/bin/env python
# Parsing.py    EXAMPLE

from pkipplib import pkipplib
import sys

fileName = sys.argv[1]

# Read IPP datas from a CUPS job control file
myfile = open(fileName)
ippdatas = myfile.read()
myfile.close()

# Parse these datas
request = pkipplib.IPPRequest(ippdatas)
request.parse()

print "job-state:" + str(request.job["job-state"][0][1])
print "job-media-sheets-completed:" + str(request.job["job-media-sheets-completed"][0][1])
print "document-format:" + str(request.job["document-format"][0][1])
