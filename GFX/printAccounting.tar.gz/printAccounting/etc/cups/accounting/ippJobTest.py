#! /usr/bin/env python
# Parsing.py    EXAMPLE

from pkipplib import pkipplib
import sys

fileName = sys.argv[1]

# Read IPP datas from a CUPS job control file
myfile = open(fileName)
ippdatas = myfile.read()
myfile.close()

# Parse these datas
request = pkipplib.IPPRequest(ippdatas)
request.parse()

#print request

print "\n\n\n"


# Create a CUPS client instance 
# cups = pkipplib.CUPS(url="http://server:631, \
#                      username="john", \
#                      password="5.%!oyu")
cups = pkipplib.CUPS()

print "\n\n\n"

# Lower level API :
request = cups.newRequest(pkipplib.IPP_GET_PRINTER_ATTRIBUTES)
request.operation["printer-uri"] = ("uri", 
                                    cups.identifierToURI("printers", "BrotherHL5170DN"))
for attribute in ("printer-uri-supported",                                     
                  "printer-type",
                  "member-uris") :
    # IMPORTANT : here, despite the unusual syntax, we append to              
    # the list of requested attributes :
    request.operation["requested-attributes"] = ("nameWithoutLanguage", attribute)
    
# Sends this request to the CUPS server    
answer = cups.doRequest(request)    

# Print the answer as a string of text
print answer
