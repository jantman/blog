<?php
require_once('/srv/www/APIkeys.php');
require_once('GoogleMapAPI-2.5/GoogleMapAPI.class.php');
require_once('mp-boundary.php');

$map = new GoogleMapAPI('map');
$map->setAPIKey($APIKEY_google_maps);

$map->setWidth('3300px');
$map->setHeight('5100px');
//$map->disableMapControls();
$map->setZoomLevel(17);
$map->disableSidebar();

//addMarkerByCoords($lon,$lat,$title = '',$html = '')
//addPolyLineByCoords($lon1,$lat1,$lon2,$lat2,$color,$weight,$opacity)

foreach($MP_boundary as $i => $arr)
{
    if($i == count($MP_boundary)-1)
    {
	// connect last to first
	$map->addPolyLineByCoords($MP_boundary[$i][0],$MP_boundary[$i][1],$MP_boundary[0][0],$MP_boundary[0][1],'#ff0000',5,100);
    }
    else
    {
	$map->addPolyLineByCoords($MP_boundary[$i][0],$MP_boundary[$i][1],$MP_boundary[$i+1][0],$MP_boundary[$i+1][1],'#ff0000',5,100);
    }
}

// ADD HYDRANTS
require_once('hydrants.php');
foreach($hydrants as $foo)
{
    if(is_array($foo))
    {
	$map->addMarkerByCoords($foo[1], $foo[0]);
    }
}

$map->setCenterCoords(-74.138677, 40.996521);

$url = "http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=midland+park,+nj+07432&amp;sll=37.0625,-95.677068&amp;sspn=50.69072,79.013672&amp;ie=UTF8&amp;hq=&amp;hnear=Midland+Park,+Bergen,+New+Jersey+07432&amp;ll=40.996521,-74.138677&amp;spn=0.023807,0.038581&amp;z=17&amp;output=embed";

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Map Test</title>
<!-- <link rel="stylesheet" type="text/css" href="XXXX.css" /> -->
<?php
$map->printHeaderJS();
$map->printMapJS();
?>
</head>

<body onload="onLoad()">

<?php $map->printMap(); ?>

</body>

</html>
