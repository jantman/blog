<?php
$hydrants = array();
// accept either address or lat/lon, loop detects whether element is string or array

// estimated MPHS
$hydrants[] = array(40.999712, -74.137783);
// estimated Paterson at Godwin
$hydrants[] = array(40.993053, -74.143854);
// begin Godwin ave at Franklin
$hydrants[] = array(40.985601, -74.139213);
$hydrants[] = array(40.985605, -74.139238);
$hydrants[] = array(40.987467, -74.140023);
$hydrants[] = array(40.988474, -74.140482);
$hydrants[] = array(40.990065, -74.141206);
$hydrants[] = array(40.991713, -74.141603);
$hydrants[] = array(40.992525, -74.142655);
$hydrants[] = array(40.995120, -74.146018);
$hydrants[] = array(40.996007, -74.146791);
$hydrants[] = array(40.996300, -74.147665);
$hydrants[] = array(40.997060, -74.148770);
$hydrants[] = array(40.998300, -74.150683);
$hydrants[] = array(40.998766, -74.152598);
$hydrants[] = array(41.000454, -74.154384);
// begin Park Ave at Godwin
$hydrants[] = array(41.000039, -74.148204);
$hydrants[] = array(41.002873, -74.144699);
$hydrants[] = array(41.003442, -74.143988);
$hydrants[] = array(41.004594, -74.142539);
$hydrants[] = array(41.005883, -74.141281);


/*
DONE:
Godwin from Goffle to Midland
Park from Godwin to Prospect


*/
?>