<?php
$MP_boundary = array();
$MP_boundary[] = array(-74.137587, 41.007597);
$MP_boundary[] = array(-74.130887, 41.006197);
$MP_boundary[] = array(-74.130887, 41.006197);
$MP_boundary[] = array(-74.130726, 41.003260);
$MP_boundary[] = array(-74.132687, 40.995597);
$MP_boundary[] = array(-74.127887, 40.994397);
$MP_boundary[] = array(-74.128087, 40.993897);
$MP_boundary[] = array(-74.132787, 40.985397);
$MP_boundary[] = array(-74.135287, 40.983097);
$MP_boundary[] = array(-74.136960, 40.981862);
$MP_boundary[] = array(-74.141052, 40.982194);
$MP_boundary[] = array(-74.141287, 40.982697);
$MP_boundary[] = array(-74.141287, 40.982697);
$MP_boundary[] = array(-74.141787, 40.984797);
$MP_boundary[] = array(-74.142787, 40.986397);
$MP_boundary[] = array(-74.148287, 40.986897);
$MP_boundary[] = array(-74.153688, 40.989997);
$MP_boundary[] = array(-74.151088, 40.992997);
$MP_boundary[] = array(-74.153188, 40.996597);
$MP_boundary[] = array(-74.157188, 40.998897);
$MP_boundary[] = array(-74.155788, 41.001397);
$MP_boundary[] = array(-74.146187, 41.001897);
$MP_boundary[] = array(-74.140087, 41.006597);
$MP_boundary[] = array(-74.137587, 41.007597);
?>