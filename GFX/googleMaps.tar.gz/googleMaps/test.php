
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Map Test</title>
<!-- <link rel="stylesheet" type="text/css" href="XXXX.css" /> -->
</head>

<?php
$url = "http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=midland+park,+nj+07432&amp;sll=37.0625,-95.677068&amp;sspn=50.69072,79.013672&amp;ie=UTF8&amp;hq=&amp;hnear=Midland+Park,+Bergen,+New+Jersey+07432&amp;ll=40.996521,-74.138677&amp;spn=0.023807,0.038581&amp;z=17&amp;output=embed";

$url .= "&amp;path=color:0xff0000ff,weight:5|40.991414,-74.143982|40.993163,-74134062|40.985712,-74.132910|40.986295,-74.142008";

?>

<body>
<iframe width="3300" height="5100" frameborder="0" scrolling="no"
marginheight="0" marginwidth="0" <?php echo 'src="'.$url.'"';?> ></iframe>

<br />

<small>
<a
href="http://maps.google.com/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=midland+park,+nj+07432&amp;sll=37.0625,-95.677068&amp;sspn=50.69072,79.013672&amp;ie=UTF8&amp;hq=&amp;hnear=Midland+Park,+Bergen,+New+Jersey+07432&amp;ll=40.996521,-74.138677&amp;spn=0.023807,0.038581&amp;z=15"
style="color:#0000FF;text-align:left">View Larger Map</a></small>

</body>

</html>
